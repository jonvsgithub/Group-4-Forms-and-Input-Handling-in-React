# Grp4AssignmentReactForm
# Question Build a form in React (e.g., a user registration form) that handles inputs and validation. • Display form data dynamically and submit the data to an API (mocked).

# Names                                                # Ids
	
# 24352	Muheruki Julien
# 24737	Kabarokore Jesca
# 24770	Ufiteyesu Rachel
# 24776	IBYISHAKA YVonne
# 24779	ISHIMWE Ange Christian
# 24801	Cyiza kayitare sabine
# 24865	Ndayizeye Jonathan
# 24872	Isingizwe Rutareka Travis
# 24874	Travis Isingizwe Rutareka
# 24906	Mihigo Kevin
# 24940	Tumukunde Reine Mari  Hyguette
# 24989	Irakoze Yvan
# 25101	Mukanyandwi Priscilla
# 25111	Habimana Daniel
# 25158	Ndayambaje Alexis
# 25312	Ntaganira Divanni
# 25430	KWIZERA NDIHO Hyacinthe
# 25496	Bintunimana Pacifique
